<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Zona extends BaseController
{
    public function tambahzona()
    {
        return view('tambahzona');
    }
}
